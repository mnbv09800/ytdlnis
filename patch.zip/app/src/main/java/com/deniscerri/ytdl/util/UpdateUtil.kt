package com.deniscerri.ytdl.util

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.preference.PreferenceManager
import com.deniscerri.ytdl.BuildConfig
import com.deniscerri.ytdl.R
import com.deniscerri.ytdl.core.RuntimeManager
import com.deniscerri.ytdl.core.models.YTDLRequest
import com.deniscerri.ytdl.core.packages.PackageBase.Companion.sharedClient
import com.deniscerri.ytdl.database.models.GithubRelease
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.cancellation.CancellationException


class UpdateUtil(var context: Context) {
    private val tag = "UpdateUtil"
    private val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

    private val channelMap = mapOf(
        Pair<String, RuntimeManager.UpdateChannel>("stable", RuntimeManager.UpdateChannel.STABLE),
        Pair<String, RuntimeManager.UpdateChannel>("nightly", RuntimeManager.UpdateChannel.NIGHTLY),
        Pair<String, RuntimeManager.UpdateChannel>("master", RuntimeManager.UpdateChannel.MASTER)
    )

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    fun tryGetNewVersion() : Result<GithubRelease> {
        try {
            val skippedVersions = sharedPreferences.getString("skip_updates", "")?.split(",")?.distinct()?.toMutableList() ?: mutableListOf()
            val res = fetchReleases()

            if (res.isEmpty()){
                return Result.failure(Error(context.getString(R.string.you_are_in_latest_version)))
            }
            sharedPreferences.edit().putLong(APP_LAST_CHECK_KEY, System.currentTimeMillis()).apply()

            val v = findUpdate(res)

            if (v == null || skippedVersions.contains(v.tag_name)) {
                return Result.failure(Error(context.getString(R.string.you_are_in_latest_version)))
            }
            return Result.success(v)
        }catch (e: Exception){
            e.printStackTrace()
            return Result.failure(e)
        }
    }

    private fun parseVersion(tag: String): List<Int>? =
        tag.removePrefix("v").replace("-beta", "").split(".").map { it.toIntOrNull() ?: return null }

    /** Part by part, so 1.10.0 is newer than 1.9.1.1, and 1.9.1 equals 1.9.1.0 */
    private fun compareVersions(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until maxOf(a.size, b.size)) {
            val diff = a.getOrElse(i) { 0 }.compareTo(b.getOrElse(i) { 0 })
            if (diff != 0) return diff
        }
        return 0
    }

    /** The release to offer from a newest first list, null if already on the latest */
    private fun findUpdate(releases: List<GithubRelease>): GithubRelease? {
        val useBeta = sharedPreferences.getBoolean("update_beta", false)
        val useNightly = sharedPreferences.getBoolean("update_nightly", false)

        if (useNightly) {
            // nightlies share the stable version name, so a nightly is new if it was published after this app was installed/updated
            val installedAt = context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
            return releases.firstOrNull { it.tag_name.startsWith("nightly-") }?.takeIf { it.published_at.time > installedAt }
        }

        val currentVersion = BuildConfig.VERSION_NAME

        val current = parseVersion(currentVersion) ?: return null
        fun GithubRelease.isNewer() = compareVersions(parseVersion(tag_name)!!, current) > 0
        // old beta tags aren't all flagged as pre-releases on GitHub, so check the name too
        fun GithubRelease.isPreRelease() = prerelease || tag_name.contains("beta", true)

        val versioned = releases.filter { parseVersion(it.tag_name) != null }
        val stable = versioned.firstOrNull { !it.isPreRelease() } ?: return null

        if (useBeta) {
            if (stable.isNewer()) return stable
            return (versioned.firstOrNull { it.isPreRelease() } ?: stable).takeIf { it.isNewer() }
        }

        //if current version is beta but wants to downgrade to stable, allow it
        if (currentVersion.contains("beta", true)) return stable
        return stable.takeIf { it.isNewer() }
    }

    private fun fetchReleases(): List<GithubRelease> {
        val conn: HttpURLConnection
        var json = listOf<GithubRelease>()
        try {
            conn = URL(RELEASES_URL).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 5000
            if (conn.responseCode < 300) {
                val myType = object : TypeToken<List<GithubRelease>>() {}.type
                json = Gson().fromJson(InputStreamReader(conn.inputStream), myType)
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.e(tag, e.toString())
        }
        return json
    }

    data class YTDLPUpdateResponse (
        val status: YTDLPUpdateStatus,
        val message: String = ""
    )

    enum class YTDLPUpdateStatus {
        DONE, ALREADY_UP_TO_DATE, PROCESSING, ERROR
    }

    suspend fun updateYTDL(c: String? = null) : YTDLPUpdateResponse =
        withContext(Dispatchers.IO){
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            if (updatingYTDL) {
                return@withContext YTDLPUpdateResponse(YTDLPUpdateStatus.PROCESSING)
            }

            updatingYTDL = true

            try {
                val channel = if (c.isNullOrBlank()) sharedPreferences.getString("ytdlp_source", "nightly") else c

                val response = when(channel) {
                    "stable", "nightly", "master" -> {
                        val res = RuntimeManager.getInstance().updateYTDL(context, channelMap[channel]!!)
                        if (res != RuntimeManager.UpdateStatus.DONE) {
                            YTDLPUpdateResponse(YTDLPUpdateStatus.ALREADY_UP_TO_DATE)
                        }else {
                            val version = RuntimeManager.getInstance().version(context)
                            YTDLPUpdateResponse(YTDLPUpdateStatus.DONE, "Updated yt-dlp to ${channel}@${version}")
                        }
                    }
                    else -> {
                        val request = YTDLRequest(emptyList())
                        request.addOption("--update-to", "$channel")

                        val res = RuntimeManager.getInstance().execute(request)
                        val out = res.out.lines().last { it.isNotBlank() }

                        when {
                            out.contains("ERROR") -> YTDLPUpdateResponse(YTDLPUpdateStatus.ERROR, out)
                            out.contains("yt-dlp is up to date") -> YTDLPUpdateResponse(YTDLPUpdateStatus.ALREADY_UP_TO_DATE, out)
                            else -> YTDLPUpdateResponse(YTDLPUpdateStatus.DONE, out)
                        }
                    }
                }

                if (response.status == YTDLPUpdateStatus.DONE || response.status == YTDLPUpdateStatus.ALREADY_UP_TO_DATE) {
                    sharedPreferences.edit().putLong(YTDLP_LAST_CHECK_KEY, System.currentTimeMillis()).apply()
                }
                response
            } finally {
                updatingYTDL = false
            }
        }

    @SuppressLint("Range", "UnspecifiedRegisterReceiverFlag")
    suspend fun downloadReleaseApk(release: GithubRelease, onProgress: (Long) -> Unit) : Result<File> {
        return withContext(Dispatchers.IO) {
            try {
                val releaseVersion = release.assets.firstOrNull {
                    it.name.contains(Build.SUPPORTED_ABIS[0])
                    && !it.name.contains("foss")
                    && !it.name.contains("izzy")
                }!!
                File(FileUtil.getDefaultApksPath()).mkdirs()
                val tempApk = File(FileUtil.getDefaultApksPath(), "${releaseVersion.browser_download_url.split("/").last()}")

                //download
                val request = Request.Builder()
                    .url(releaseVersion.browser_download_url)
                    .build()

                val response = sharedClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Throwable(response.body.string()))
                }

                val body = response.body
                val totalBytes = body.contentLength()
                var bytesDownloaded = 0L

                body.byteStream().use { inputStream ->
                    tempApk.outputStream().use { outputStream ->
                        val buffer = ByteArray(8192) // 8KB buffer
                        var bytesRead: Int

                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            if (!isActive) throw CancellationException("Download cancelled by user")

                            outputStream.write(buffer, 0, bytesRead)
                            bytesDownloaded += bytesRead

                            // Calculate percentage
                            val progress = ((bytesDownloaded * 100) / totalBytes)
                            onProgress(progress)
                        }
                    }
                }

                Result.success(tempApk)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    companion object {
        const val RELEASES_URL = ""
        const val APP_LAST_CHECK_KEY = "app_last_update_check"
        const val YTDLP_LAST_CHECK_KEY = "ytdlp_last_update_check"
        var updatingYTDL = false
        var updatingApp = false
    }
}